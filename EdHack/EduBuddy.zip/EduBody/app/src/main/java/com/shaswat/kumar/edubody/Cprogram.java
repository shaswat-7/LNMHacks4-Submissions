package com.shaswat.kumar.edubody;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.view.View;
import android.widget.TextView;

import org.w3c.dom.Text;

public class Cprogram extends AppCompatActivity {

    private Toolbar toolbar;

    private TextView LearnTheBasic;
    private TextView ExploreMore;
    private TextView Youtube;
    private TextView LearnAboutArrays;
    private TextView ArrayDataStructure;
    private TextView CArrays;
    private TextView ArrProb1;
    private TextView ArrProb2;
    private TextView ArrProb3;
    private TextView TimeComplexity;
    private TextView Big0;
    private TextView ComplexityAnalysis;
    private TextView complexProb1;
    private TextView comlexprob2;
    private TextView StartFun;
    private TextView MoreFun;
    private TextView Recursion;
    private TextView recProb1em1;
    private TextView recProblem2;
    private TextView endlessC;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cprogram);


                toolbar = findViewById(R.id.toolbar_note);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("C Programming");

        bindingTextViews();


        gettingActions();




    }

     public void bindingTextViews(){


        LearnTheBasic = findViewById(R.id.Cbasics);
        ExploreMore = findViewById(R.id.cExplore);
        Youtube = findViewById(R.id.CYoutube);
        LearnAboutArrays = findViewById(R.id.CLearnAboutArray);
        ArrayDataStructure = findViewById(R.id.CLearnDSA);
        CArrays = findViewById(R.id.C_Array);
        ArrProb1 = findViewById(R.id.CArrayQ1);
        ArrProb2 = findViewById(R.id.CArrayQ2);
        ArrProb3 = findViewById(R.id.CArrayQ3);

        TimeComplexity = findViewById(R.id.CTimeComlexity);
        Big0 = findViewById(R.id.CBig0);
        ComplexityAnalysis = findViewById(R.id.CComAnalysis);
        complexProb1 = findViewById(R.id.CTimeAnalysisQ1);
        comlexprob2 = findViewById(R.id.CTimeAnalysisQ2);

        StartFun = findViewById(R.id.CGEtFunction);
        MoreFun = findViewById(R.id.CFUnMore);
        Recursion = findViewById(R.id.CRecursion);
        recProb1em1 = findViewById(R.id.CproblemFun1);
        recProblem2 =findViewById(R.id.CproblemFun2);

        endlessC = findViewById(R.id.CGuide);


     }


     public void gettingActions(){


        endlessC.setMovementMethod(LinkMovementMethod.getInstance());
        endlessC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("https://nptel.ac.in/courses/106104128/"));
                startActivity(intent);
            }
        });

         LearnTheBasic.setMovementMethod(LinkMovementMethod.getInstance());
         LearnTheBasic.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {

                 Intent intent = new Intent(Intent.ACTION_VIEW);
                 intent.setData(Uri.parse("https://www.geeksforgeeks.org/c-language-set-1-introduction/"));
                 startActivity(intent);
             }
         });
         ExploreMore.setMovementMethod(LinkMovementMethod.getInstance());
         ExploreMore.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {

                 Intent intent = new Intent(Intent.ACTION_VIEW);
                 intent.setData(Uri.parse("https://www.tutorialspoint.com/cprogramming/index.htm"));
                 startActivity(intent);
             }
         });
         Youtube.setMovementMethod(LinkMovementMethod.getInstance());
         Youtube.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {

                 Intent intent = new Intent(Intent.ACTION_VIEW);
                 intent.setData(Uri.parse("https://www.youtube.com/watch?v=-CpG3oATGIs"));
                 startActivity(intent);
             }
         });
         LearnAboutArrays.setMovementMethod(LinkMovementMethod.getInstance());
         LearnAboutArrays.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {

                 Intent intent = new Intent(Intent.ACTION_VIEW);
                 intent.setData(Uri.parse("https://www.javatpoint.com/c-array"));
                 startActivity(intent);
             }
         });
         ArrayDataStructure.setMovementMethod(LinkMovementMethod.getInstance());
         ArrayDataStructure.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {

                 Intent intent = new Intent(Intent.ACTION_VIEW);
                 intent.setData(Uri.parse("https://www.cs.cmu.edu/~rjsimmon/15122-f14/lec/04-arrays.pdf"));
                 startActivity(intent);
             }
         });
         CArrays.setMovementMethod(LinkMovementMethod.getInstance());
         CArrays.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {

                 Intent intent = new Intent(Intent.ACTION_VIEW);
                 intent.setData(Uri.parse("https://www.youtube.com/watch?v=SPuS9UJF1lo"));
                 startActivity(intent);
             }
         });
         ArrProb1.setMovementMethod(LinkMovementMethod.getInstance());
         ArrProb1.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {

                 Intent intent = new Intent(Intent.ACTION_VIEW);
                 intent.setData(Uri.parse("https://www.codechef.com/problems/LECANDY"));
                 startActivity(intent);
             }
         });
        ArrProb2.setMovementMethod(LinkMovementMethod.getInstance());
         ArrProb2.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {

                 Intent intent = new Intent(Intent.ACTION_VIEW);
                 intent.setData(Uri.parse("https://www.codechef.com/problems/COPS"));
                 startActivity(intent);
             }
         });
         ArrProb3.setMovementMethod(LinkMovementMethod.getInstance());
         ArrProb3.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {

                 Intent intent = new Intent(Intent.ACTION_VIEW);
                 intent.setData(Uri.parse("https://www.codechef.com/problems/SALARY"));
                 startActivity(intent);
             }
         });

         TimeComplexity.setMovementMethod(LinkMovementMethod.getInstance());
         TimeComplexity.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {

                 Intent intent = new Intent(Intent.ACTION_VIEW);
                 intent.setData(Uri.parse("https://www.youtube.com/watch?v=V42FBiohc6c&list=PL2_aWCzGMAwI9HK8YPVBjElbLbI3ufctn"));
                 startActivity(intent);
             }
         });
         Big0.setMovementMethod(LinkMovementMethod.getInstance());
         Big0.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {

                 Intent intent = new Intent(Intent.ACTION_VIEW);
                 intent.setData(Uri.parse("https://www.youtube.com/watch?v=i1F_Uu0bYCc"));
                 startActivity(intent);
             }
         });
         ComplexityAnalysis.setMovementMethod(LinkMovementMethod.getInstance());
         ComplexityAnalysis.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {

                 Intent intent = new Intent(Intent.ACTION_VIEW);
                 intent.setData(Uri.parse("https://www.hackerearth.com/practice/basic-programming/complexity-analysis/time-and-space-complexity/tutorial/"));
                 startActivity(intent);
             }
         });
         complexProb1.setMovementMethod(LinkMovementMethod.getInstance());
         complexProb1.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {

                 Intent intent = new Intent(Intent.ACTION_VIEW);
                 intent.setData(Uri.parse("http://www.iitk.ac.in/esc101/08Jul/lecnotes/practise_sol.pdf"));
                 startActivity(intent);
             }
         });
         comlexprob2.setMovementMethod(LinkMovementMethod.getInstance());
         comlexprob2.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {

                 Intent intent = new Intent(Intent.ACTION_VIEW);
                 intent.setData(Uri.parse("https://discuss.codechef.com/t/multiple-choice-questions-related-to-testing-knowledge-about-time-and-space-complexity-of-a-program/17976"));
                 startActivity(intent);
             }
         });
         StartFun.setMovementMethod(LinkMovementMethod.getInstance());
         StartFun.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {

                 Intent intent = new Intent(Intent.ACTION_VIEW);
                 intent.setData(Uri.parse("https://www.geeksforgeeks.org/functions-in-c"));
                 startActivity(intent);
             }
         });

         MoreFun.setMovementMethod(LinkMovementMethod.getInstance());
         MoreFun.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {

                 Intent intent = new Intent(Intent.ACTION_VIEW);
                 intent.setData(Uri.parse("https://beginnersbook.com/2014/01/c-functions-examples/"));
                 startActivity(intent);
             }
         });
         Recursion.setMovementMethod(LinkMovementMethod.getInstance());
         Recursion.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {

                 Intent intent = new Intent(Intent.ACTION_VIEW);
                 intent.setData(Uri.parse("https://www.topcoder.com/community/data-science/data-science-tutorials/an-introduction-to-recursion-part-1/"));
                 startActivity(intent);
             }
         });
         recProb1em1.setMovementMethod(LinkMovementMethod.getInstance());
         recProb1em1.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {

                 Intent intent = new Intent(Intent.ACTION_VIEW);
                 intent.setData(Uri.parse("https://www.geeksforgeeks.org/practice-questions-for-recursion/"));
                 startActivity(intent);
             }
         });
         recProblem2.setMovementMethod(LinkMovementMethod.getInstance());
         recProblem2.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {

                 Intent intent = new Intent(Intent.ACTION_VIEW);
                 intent.setData(Uri.parse("https://www.geeksforgeeks.org/practice-questions-for-recursion-set-2/"));
                 startActivity(intent);
             }
         });

     }
}
